<?php echo $total_inventori
