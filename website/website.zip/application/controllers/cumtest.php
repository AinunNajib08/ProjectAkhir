<?php
defined('BASEPATH') or exit('No direct script access allowed');

class cumatest extends CI_Controller
{

    function dataipa()
    {
        $this->load->view("cumatest");
        // $this->load->view("admin/dataipa");
    }
}
