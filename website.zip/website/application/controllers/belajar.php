<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Belajar extends CI_Controller
{

    function pemrograman()
    {
        echo "MENGHILANGKAN INDEX.PHP PADA CODEIGNITER | MALASNGODING.COM";
    }
}
